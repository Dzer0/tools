#!/bin/sh
cd start
sh start_cluster.sh
sh create_redis_cluster.sh
